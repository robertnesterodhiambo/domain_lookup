import pandas as pd
import mysql.connector
import math

# Database configuration
DB_CONFIG = {
    'user': 'root',
    'password': 'root235',
    'host': '157.90.17.11',
    'database': 'domain_data'
}

# File path
csv_file = 'tes_accesibilty_with_pages.csv'

# Read CSV into DataFrame
df = pd.read_csv(csv_file)

# Connect to MySQL
conn = mysql.connector.connect(**DB_CONFIG)
cursor = conn.cursor()

# Create table with columns based on CSV headers
columns = df.columns.tolist()
col_defs = ', '.join([f"`{col}` TEXT" for col in columns])
create_table_query = f"CREATE TABLE IF NOT EXISTS complete ({col_defs})"
cursor.execute(create_table_query)
conn.commit()

# Unique column definition
unique_column = 'domain'

# Get existing domain values from database to skip duplicates
cursor.execute(f"SELECT `{unique_column}` FROM complete")
existing = set(row[0] for row in cursor.fetchall())

# Insert data while skipping existing
insert_query = f"INSERT INTO complete ({', '.join(['`'+col+'`' for col in columns])}) VALUES ({', '.join(['%s']*len(columns))})"

skipped = 0
inserted = 0

for _, row in df.iterrows():
    domain_value = str(row[unique_column])
    if domain_value in existing:
        skipped += 1
        continue
    # Convert NaN to None for SQL NULL insertion
    values = [None if (isinstance(v, float) and math.isnan(v)) else v for v in row]
    cursor.execute(insert_query, tuple(values))
    inserted += 1

conn.commit()

print(f"Skipped: {skipped} rows")
print(f"Inserted: {inserted} rows")

# Close connection
cursor.close()
conn.close()
